/******************************************************************************
 *
 * Program: TempTrax Model E Plugin For Nagios
 * Author:  Ethan Galstad (nagios@nagios.org)
 * Last Modified:  06-19-2003
 * License: GPL
 *
 * Description:
 * 
 * This plugin is designed to check the temperature of a probe connected to
 * a TempTrax Model E.  4-, 8- and 16-port models are supported.
 *
 * Notes:
 * 
 * Network code pulled from NetSaint/Nagios plugin code, which is copyrighted
 * by Ethan Galstad, Karl DeBisschop and others.  See the AUTHORS file for the
 * Nagios plugins for more information.
 *
 * License Information:
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *****************************************************************************/

#include "../include/config.h"
#include "../include/common.h"


#define DEFAULT_TIMEOUT 10
#define BUFFER_SIZE     2048
#define TT_PROBES       16
	

int process_arguments(int,char **);
int process_tempdata(void);

int process_tcp_request2(char *,int,char *,char *,int);
int my_connect(char *,int,int *,char *);
int my_inet_aton(register const char *, struct in_addr *);

extern int errno;


probe ttprobe[TT_PROBES];

int show_usage=FALSE;

char *host_address=NULL;
int probe_number=1;
int socket_timeout=DEFAULT_TIMEOUT;
int invert_test=FALSE;
int use_celsius=FALSE;
double warn_temp=1000.0;
double crit_temp=1000.0;

char sendbuf[BUFFER_SIZE];
char recvbuf[BUFFER_SIZE];


int main(int argc, char **argv){
	int result=STATE_OK;
	probe tp;
	char *result_tag="";

	/* process command-line arguments */
	result=process_arguments(argc,argv);

	if(result==ERROR)
		printf("Error: Incorrect command line arguments\n\n");

	if(result==ERROR || show_usage==TRUE){
		printf("TempTrax Model E Plugin for Nagios\n");
		printf("Copyright (c) 2003 Ethan Galstad (nagios@nagios.org)\n");
		printf("License: GPL\n\n");
		printf("Usage: %s -H <host> -p <probe_num> -w <warn_temp> -c <crit_temp>\n",argv[0]);
		printf("       [--invert] [--celsius | --farenheit]\n");
		printf("\n");
		printf("Options:\n");
		printf("\n");
		printf(" -H <host>      = IP address of TempTrax Model E\n");
		printf(" -p <probe_num> = Probe number to check (1-16)\n");
		printf(" -w <warn_temp> = Warning temperature threshold\n");
		printf(" -c <crit_temp> = Crtical temperature threshold\n");
		printf(" --invert       = Invert normal temp threshold checking, so that colder\n");
		printf("                  temperatures are more critical that warmer ones\n");
		printf(" --celsius      = Temp thresholds are specified in degrees Celsius\n");
		printf(" --farenheit    = Temp thresholds are specified in degrees Farenheit (default)\n");
		printf("\n");
		printf("Notes:\n");
		printf("\n");
		printf("This plugin is designed to check temperature readings of probes attached to\n");
		printf("TempTrax Model E devices (4-, 8-, or 16-port models).  More information on\n");
		printf("TempTrax devices can be found at http://www.sensatronics.com\n");
		printf("\n");

		return STATE_UNKNOWN;
	        }


	/* reset alarm */
	alarm(0);

	/* grab temp data from host */
	strcpy(recvbuf,"");
	result=process_tcp_request2(host_address,80,"GET /temp HTTP/1.0\r\n\r\n",recvbuf,sizeof(recvbuf));
	if(result!=STATE_OK)
		exit(result);

	/* process temp data */
	process_tempdata();

	tp=ttprobe[probe_number-1];

	/* check for an error */
	if(tp.error==TRUE || tp.present==FALSE){
		printf("Error: Unable to read temperature from probe #%d\n",probe_number);
		result=STATE_CRITICAL;
	        }
	else if(tp.temp==-99.9){
		printf("Error: Probe #%d appears to be disconnected\n",probe_number);
		result=STATE_CRITICAL;
	        }

	/* check probe temp values */
	else{

		result=STATE_OK;

		if(invert_test==TRUE){
			if(tp.temp<=crit_temp)
				result=STATE_CRITICAL;
			else if(tp.temp<=warn_temp)
				result=STATE_WARNING;
		        }
		else{
			if(tp.temp>=crit_temp)
				result=STATE_CRITICAL;
			else if(tp.temp>=warn_temp)
				result=STATE_WARNING;
		        }

		if(result==STATE_CRITICAL)
			result_tag="Critical";
		else if(result==STATE_WARNING)
			result_tag="Warning";
		else
			result_tag="Ok";

		printf("Temp %s: %s = ",result_tag,(tp.name==NULL)?"Probe":tp.name);
		if(use_celsius==FALSE)
			printf("%.1lf F\n",tp.temp);
		else
			printf("%.1lf C\n",((tp.temp-32.0)*5.0/9.0));
	        }

	return result;
        }


/* process temp data */
int process_tempdata(void){
	int x;
	char *ptr;
	char *endptr=NULL;

	/* initialize probe values */
	for(x=0;x<TT_PROBES;x++){
		ttprobe[x].name=NULL;
		ttprobe[x].present=FALSE;
		ttprobe[x].error=TRUE;
		ttprobe[x].temp=-99.9;
	        }

#ifdef DEBUG
	printf("RAW DATA:\n%s\n",recvbuf);
#endif

	for(x=0;x<TT_PROBES;x++){

		/* get probe name */
		ptr=strtok((x==0)?recvbuf:NULL,"|");
		if(ptr==NULL)
			break;
		ttprobe[x].name=strdup(ptr);
		
		/* get probe temp */
		ptr=strtok(NULL,"|");
		if(ptr==NULL)
			break;
		/* make an adjustment for temps between -10 and 0 */
		if(ptr[0]=='-' && ptr[1]==' '){
			ptr++;
			ptr[0]='-';
		        }
		ttprobe[x].temp=strtod(ptr,&endptr);
		ttprobe[x].present=TRUE;
		if(endptr==ptr)
			ttprobe[x].error=TRUE;
		else
			ttprobe[x].error=FALSE;
	        }

#ifdef DEBUG
	for(x=0;x<TT_PROBES;x++)
		printf("PROBE %d: Name=%s, Temp=%.1lf, Error=%d, Present=%d\n",x+1,ttprobe[x].name,ttprobe[x].temp,ttprobe[x].error,ttprobe[x].present);
#endif


	return OK;
        }

	
/* process command-line arguments */
int process_arguments(int argc, char **argv){
        int x;

        /* no options were supplied */
        if(argc<2) return ERROR;

	for(x=1;x<argc;x++){

		if(!strcmp(argv[x],"-H") || !strcmp(argv[x],"--host")){
			if(x+1>=argc || argv[x+1]==NULL)
				return ERROR;
			x++;
			host_address=argv[x];
		        }
		else if(!strcmp(argv[x],"-p") || !strcmp(argv[x],"--probe")){
			if(x+1>=argc || argv[x+1]==NULL)
				return ERROR;
			x++;
			probe_number=atoi(argv[x]);
		        }
		else if(!strcmp(argv[x],"-t") || !strcmp(argv[x],"--timeout")){
			if(x+1>=argc || argv[x+1]==NULL)
				return ERROR;
			x++;
			socket_timeout=atoi(argv[x]);
			if(socket_timeout<=0)
				return ERROR;
		        }
		else if(!strcmp(argv[x],"-w") || !strcmp(argv[x],"--warning")){
			if(x+1>=argc || argv[x+1]==NULL)
				return ERROR;
			x++;
			warn_temp=atof(argv[x]);
		        }
		else if(!strcmp(argv[x],"-c") || !strcmp(argv[x],"--critical")){
			if(x+1>=argc || argv[x+1]==NULL)
				return ERROR;
			x++;
			crit_temp=atof(argv[x]);
		        }
		else if(!strcmp(argv[x],"--invert"))
			invert_test=TRUE;
		else if(!strcmp(argv[x],"--celsius"))
			use_celsius=TRUE;
		else if(!strcmp(argv[x],"--farenheit"))
			use_celsius=FALSE;
	        }

	/* make sure we have required args */
	if(host_address==NULL)
		return ERROR;

	/* make sure thresholds make sense */
	if(((warn_temp>crit_temp) && invert_test==FALSE) || ((warn_temp<crit_temp) && invert_test==TRUE))
		return ERROR;

	/* make sure probe numbers are value */
	if(probe_number<=0 || probe_number>TT_PROBES)
		return ERROR;

	/* convert threshold values to farenheit if necessary */
	if(use_celsius==TRUE){
		warn_temp=(warn_temp*9.0/5.0)+32.0;
		crit_temp=(crit_temp*9.0/5.0)+32.0;
	        }

	return OK;
        }




/******************************************************************/
/******************************************************************/
/* NETWORK FUNCTIONS - Pulled from main Nagios plugins code       */
/******************************************************************/
/******************************************************************/


/* connects to a host on a specified tcp port, sends a string, and gets a 
	 response. loops on select-recv until timeout or eof to get all of a 
	 multi-packet answer */ 
int process_tcp_request2 (char *server_address, 
	int server_port,
	char *send_buffer,
	char *recv_buffer,
	int recv_size)
{
 
	int result;
	int send_result;
	int recv_result;
	int sd;
	struct timeval tv;
	fd_set readfds;
	int recv_length = 0;

	result=my_connect(server_address,server_port,&sd,"tcp");
	if (result!=STATE_OK)
		return STATE_CRITICAL;

	send_result=send(sd,send_buffer,strlen(send_buffer),0);
	if (send_result!=strlen(send_buffer)) {
		printf("send() failed\n");
		result=STATE_WARNING;
	}

	while (1) {
		/* wait up to the number of seconds for socket timeout
			 minus one for data from the host */
		tv.tv_sec=socket_timeout-1;
		tv.tv_usec=0;
		FD_ZERO(&readfds);
		FD_SET(sd,&readfds);
		select(sd+1,&readfds,NULL,NULL,&tv);

		/* make sure some data has arrived */
		if (!FD_ISSET(sd,&readfds)) { /* it hasn't */
			if ( ! recv_length ) {
				strcpy(recv_buffer,"");
				printf("No data was recieved from host!\n");
				result=STATE_WARNING;
			} else { /* this one failed, but previous ones worked */
				recv_buffer[recv_length]=0;
			}
			break;
		} else{ /* it has */
			recv_result=recv(sd, recv_buffer + recv_length, recv_size-recv_length-1, 0);
			if (recv_result==-1) { /* recv failed, bail out */
				strcpy(recv_buffer+recv_length,"");
				result=STATE_WARNING;
				break;
			} else if ( recv_result == 0 ) { /* end of file ?*/
				recv_buffer[recv_length]=0;
				break;
			} else { /* we got data! */
				recv_length += recv_result;
				if ( recv_length >= recv_size - 1 ) { /* buffer full, we're done */
					recv_buffer[recv_size-1]=0;
					break;
				}
			}
		} /* end if(!FD_ISSET(sd,&readfds)) */
	} /* end while(1) */

	close(sd); 
	return result; 
}



/* opens a tcp or udp connection to a remote host */
int my_connect (char *host_name, int port, int *sd, char *proto)
{
	struct sockaddr_in servaddr;
	struct hostent *hp;
	struct protoent *ptrp;
	int result;

	bzero((char *)&servaddr,sizeof(servaddr));
	servaddr.sin_family=AF_INET;
	servaddr.sin_port=htons(port);

	/* try to bypass using a DNS lookup if this is just an IP address */
	if(!my_inet_aton(host_name,&servaddr.sin_addr)){

		/* else do a DNS lookup */
		hp=gethostbyname((const char *)host_name);
		if(hp==NULL){
			printf("Invalid host name '%s'\n",host_name);
			return STATE_UNKNOWN;
		}

		memcpy(&servaddr.sin_addr,hp->h_addr,hp->h_length);
	}

	/* map transport protocol name to protocol number */
	if((ptrp=getprotobyname(proto))==NULL){
		printf("Cannot map \"%s\" to protocol number\n",proto);
		return STATE_UNKNOWN;
	}

	/* create a socket */
	*sd=socket(PF_INET,(!strcmp(proto,"udp"))?SOCK_DGRAM:SOCK_STREAM,ptrp->p_proto);
	if(*sd<0){
		printf("Socket creation failed\n");
		return STATE_UNKNOWN;
	}

	/* open a connection */
	result=connect(*sd,(struct sockaddr *)&servaddr,sizeof(servaddr));
	if(result<0){
		switch(errno){  
		case ECONNREFUSED:
			printf("Connection refused by host\n");
			break;
		case ETIMEDOUT:
			printf("Timeout while attempting connection\n");
			break;
		case ENETUNREACH:
			printf("Network is unreachable\n");
			break;
		default:
			printf("Connection refused or timed out\n");
		}

		return STATE_CRITICAL;
	}

	return STATE_OK;
}



/* This code was taken from Fyodor's nmap utility, which was originally
	 taken from the GLIBC 2.0.6 libraries because Solaris doesn't contain
	 the inet_aton() funtion. */
int my_inet_aton(register const char *cp, struct in_addr *addr)
{
	register unsigned int val;	/* changed from u_long --david */
	register int base, n;
	register char c;
	u_int parts[4];
	register u_int *pp = parts;

	c=*cp;

	for(;;){

		/*
		 * Collect number up to ``.''.
		 * Values are specified as for C:
		 * 0x=hex, 0=octal, isdigit=decimal.
		 */
		if (!isdigit((int)c))
			return (0);
		val=0;
		base=10;

		if(c=='0'){
			c=*++cp;
			if(c=='x'||c=='X')
				base=16,c=*++cp;
			else
				base=8;
		}

		for(;;){
			if(isascii((int)c) && isdigit((int)c)){
				val=(val*base)+(c -'0');
				c=*++cp;
			} 
			else if(base==16 && isascii((int)c) && isxdigit((int)c)) {
				val=(val<<4) | (c+10-(islower((int)c)?'a':'A'));
				c = *++cp;
			} 
			else
				break;
		}

		if(c=='.'){

			/*
			 * Internet format:
			 *	a.b.c.d
			 *	a.b.c	(with c treated as 16 bits)
			 *	a.b	(with b treated as 24 bits)
			 */
			if(pp>=parts+3)
				return (0);
			*pp++=val;
			c=*++cp;
		} 
		else
			break;
	}

	/* Check for trailing characters */
	if(c!='\0' && (!isascii((int)c) || !isspace((int)c)))
		return (0);

	/* Concoct the address according to the number of parts specified */
	n=pp-parts+1;
	switch(n){

	case 0:
		return (0);		/* initial nondigit */

	case 1:				/* a -- 32 bits */
		break;

	case 2:				/* a.b -- 8.24 bits */
		if(val>0xffffff)
			return (0);
		val |= parts[0]<<24;
		break;

	case 3:				/* a.b.c -- 8.8.16 bits */
		if(val>0xffff)
			return (0);
		val |= (parts[0]<< 24) | (parts[1]<<16);
		break;

	case 4:				/* a.b.c.d -- 8.8.8.8 bits */
		if(val>0xff)
			return (0);
		val |= (parts[0]<<24) | (parts[1]<<16) | (parts[2]<<8);
		break;
	}

	if(addr)
		addr->s_addr=htonl(val);

	return (1);
}
