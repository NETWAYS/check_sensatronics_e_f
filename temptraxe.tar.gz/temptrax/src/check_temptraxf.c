/******************************************************************************
 *
 * Program: TempTrax Model F Plugin For Nagios
 * Author:  Ethan Galstad (nagios@nagios.org)
 * Last Modified:  07-07-2003
 * License: GPL
 *
 * Description:
 * 
 * This plugin is designed to check the temperature of a probe connected to
 * a TempTrax Model F (serial port model0.
 *
 *****************************************************************************/

#include "../include/config.h"
#include "../include/common.h"

#define DEFAULT_TIMEOUT 5
#define BUFFER_SIZE    1024
#define TT_PROBES      2

	
int process_arguments(int,char **);
int process_tempdata(void);
void timeout_handler(int);


extern int errno;

probe ttprobe[TT_PROBES];

int show_usage=FALSE;

char *device=NULL;
int probe_number=1;
int battery_ok=FALSE;
int timeout=DEFAULT_TIMEOUT;
int invert_test=FALSE;
int use_celsius=FALSE;
double warn_temp=1000.0;
double crit_temp=1000.0;

char sendbuf[BUFFER_SIZE];
char recvbuf[BUFFER_SIZE];
int fd;
struct termios oldtios;
struct termios newtios;


int main(int argc, char **argv){
	int result=STATE_OK;
	probe tp;
	char *result_tag="";
	int readresult;
	struct timespec ts;
	struct timeval tv;
	fd_set readfs;
	int dtr_flag;

	/* process command-line arguments */
	result=process_arguments(argc,argv);

	if(result==ERROR)
		printf("Error: Incorrect command line arguments\n\n");

	if(result==ERROR || show_usage==TRUE){
		printf("TempTrax Model F Plugin for Nagios\n");
		printf("Copyright (c) 2003 Ethan Galstad (nagios@nagios.org)\n");
		printf("License: GPL\n\n");
		printf("Usage: %s -d <device> -p <probe_num> -w <warn_temp> -c <crit_temp>\n",argv[0]);
		printf("       [--invert] [--celsius | --farenheit]\n");
		printf("\n");
		printf("Options:\n");
		printf("\n");
		printf(" -d <device>    = Device TempTrax Model F is connected to (i.e. /dev/ttyS0)\n");
		printf(" -p <probe_num> = Probe number to check (1-2)\n");
		printf(" -w <warn_temp> = Warning temperature threshold\n");
		printf(" -c <crit_temp> = Crtical temperature threshold\n");
		printf(" --invert       = Invert normal temp threshold checking, so that colder\n");
		printf("                  temperatures are more critical that warmer ones\n");
		printf(" --celsius      = Temp thresholds are specified in degrees Celsius\n");
		printf(" --farenheit    = Temp thresholds are specified in degrees Farenheit (default)\n");
		printf("\n");
		printf("Notes:\n");
		printf("\n");
		printf("This plugin is designed to check temperature readings of probes attached to\n");
		printf("TempTrax Model F devices.  More information on TempTrax devices can be found\n");
		printf("at http://www.sensatronics.com\n");
		printf("\n");

		return STATE_UNKNOWN;
	        }


	/* catch timeouts */
	signal(SIGALRM,timeout_handler);
	alarm(timeout);

	/* open COM port */
	fd=open(device,O_RDWR | O_NOCTTY);
	if(fd<0){
		printf("Error: Could not open %s for reading/writing!\n",device);
		exit(STATE_CRITICAL);
	        }

	/* save current COM port settings */
	tcgetattr(fd,&oldtios);

	/* set new COM port settings */
	newtios.c_cflag=B9600 | CS8 | CLOCAL | CREAD;
	newtios.c_iflag=IGNBRK;
	newtios.c_oflag=0;
	newtios.c_lflag=0;
#ifdef HAVE_TERMIOS_C_LINE
	newtios.c_line=0;
#endif
	newtios.c_cc[VMIN]=0;
	newtios.c_cc[VTIME]=5;
	tcflush(fd,TCIFLUSH);
	tcsetattr(fd,TCSANOW,&newtios);

	/* set DTR high - this powers this TempTrax! */
	dtr_flag=TIOCM_DTR;
	ioctl(fd,TIOCMBIS,&dtr_flag);

	/* sleep a bit */
	ts.tv_sec=0;
	ts.tv_nsec=500000000;
	nanosleep(&ts,NULL);

	/* wake up the probe by sending a character (or four) */
	strcpy(sendbuf,"AT\r\n");
	write(fd,sendbuf,strlen(sendbuf)+1);

	/* sleep a bit - this is kludge, but it works ok */
	ts.tv_sec=1;
	ts.tv_nsec=0;
	nanosleep(&ts,NULL);

	/* wait for data to arrive */
#ifdef DONT_USER
	FD_ZERO(&readfs);
	FD_SET(fd,&readfs);
	tv.tv_sec=1;
	tv.tv_usec=500000;
	select(fd+1,&readfs,NULL,NULL,&tv);
#endif

	/* read temp values */
	strcpy(recvbuf,"");
	readresult=read(fd,recvbuf,sizeof(recvbuf));

	/* restore original COM port settings and close it */
	tcsetattr(fd,TCSANOW,&oldtios);
	close(fd);

	/* reset alarm */
	alarm(0);

	/* process temp data */
	process_tempdata();

	tp=ttprobe[probe_number-1];

	/* check for an error */
	if(tp.error==TRUE || tp.present==FALSE){
		printf("Error: Unable to read temperature from probe #%d\n",probe_number);
		result=STATE_CRITICAL;
	        }
	else if(tp.temp==-99.9){
		printf("Error: Probe #%d appears to be disconnected\n",probe_number);
		result=STATE_CRITICAL;
	        }

	/* check probe temp values */
	else{

		result=STATE_OK;

		if(invert_test==TRUE){
			if(tp.temp<=crit_temp)
				result=STATE_CRITICAL;
			else if(tp.temp<=warn_temp)
				result=STATE_WARNING;
		        }
		else{
			if(tp.temp>=crit_temp)
				result=STATE_CRITICAL;
			else if(tp.temp>=warn_temp)
				result=STATE_WARNING;
		        }

		/* warning if battery is not ok */
		if(result==STATE_OK && battery_ok==FALSE)
			result=STATE_WARNING;

		if(result==STATE_CRITICAL)
			result_tag="Critical";
		else if(result==STATE_WARNING)
			result_tag="Warning";
		else
			result_tag="Ok";

		printf("Temp %s: Probe #%d = ",result_tag,probe_number);
		if(use_celsius==FALSE)
			printf("%.1lf F",tp.temp);
		else
			printf("%.1lf C",((tp.temp-32.0)*5.0/9.0));
		printf(", Battery %s\n",(battery_ok==TRUE)?"Ok":"Problem");
	        }

	return result;
        }


/* process temp data */
int process_tempdata(void){
	int x;
	char *ptr;
	char *endptr=NULL;

	/* initialize probe values */
	for(x=0;x<TT_PROBES;x++){
		ttprobe[x].name=NULL;
		ttprobe[x].present=FALSE;
		ttprobe[x].error=TRUE;
		ttprobe[x].temp=-99.9;
	        }

#ifdef DEBUG
	printf("RAW DATA:\n%s\n",recvbuf);
#endif

	for(x=0;x<TT_PROBES;x++){

		/* read the probe temp */
		ptr=strtok((x==0)?recvbuf:NULL,"\r\n ");
		if(ptr==NULL)
			break;
		/* make an adjustment for temps between -10 and 0 */
		if(ptr[0]=='-' && ptr[1]==' '){
			ptr++;
			ptr[0]='-';
		        }
		ttprobe[x].temp=strtod(ptr,&endptr);
		ttprobe[x].present=TRUE;
		if(endptr==ptr)
			ttprobe[x].error=TRUE;
		else
			ttprobe[x].error=FALSE;
	        }

	/* get battery condition */
	ptr=strtok(NULL,"\r\n");
	if(ptr!=NULL){
		if(!strcmp(ptr,"Bat Ok"))
			battery_ok=TRUE;
	        }

#ifdef DEBUG
	for(x=0;x<TT_PROBES;x++)
		printf("PROBE %d: Temp=%.1lf, Error=%d, Present=%d\n",x+1,ttprobe[x].temp,ttprobe[x].error,ttprobe[x].present);
	printf("BATTERY OK: %d\n",battery_ok);
#endif


	return OK;
        }

	
/* process command-line arguments */
int process_arguments(int argc, char **argv){
        int x;

        /* no options were supplied */
        if(argc<2) return ERROR;

	for(x=1;x<argc;x++){

		if(!strcmp(argv[x],"-d") || !strcmp(argv[x],"--device")){
			if(x+1>=argc || argv[x+1]==NULL)
				return ERROR;
			x++;
			device=argv[x];
		        }
		else if(!strcmp(argv[x],"-p") || !strcmp(argv[x],"--probe")){
			if(x+1>=argc || argv[x+1]==NULL)
				return ERROR;
			x++;
			probe_number=atoi(argv[x]);
		        }
		else if(!strcmp(argv[x],"-t") || !strcmp(argv[x],"--timeout")){
			if(x+1>=argc || argv[x+1]==NULL)
				return ERROR;
			x++;
			timeout=atoi(argv[x]);
			if(timeout<=0)
				return ERROR;
		        }
		else if(!strcmp(argv[x],"-w") || !strcmp(argv[x],"--warning")){
			if(x+1>=argc || argv[x+1]==NULL)
				return ERROR;
			x++;
			warn_temp=atof(argv[x]);
		        }
		else if(!strcmp(argv[x],"-c") || !strcmp(argv[x],"--critical")){
			if(x+1>=argc || argv[x+1]==NULL)
				return ERROR;
			x++;
			crit_temp=atof(argv[x]);
		        }
		else if(!strcmp(argv[x],"--invert"))
			invert_test=TRUE;
		else if(!strcmp(argv[x],"--celsius"))
			use_celsius=TRUE;
		else if(!strcmp(argv[x],"--farenheit"))
			use_celsius=FALSE;
	        }

	/* make sure we have required args */
	if(device==NULL)
		return ERROR;

	/* make sure thresholds make sense */
	if(((warn_temp>crit_temp) && invert_test==FALSE) || ((warn_temp<crit_temp) && invert_test==TRUE))
		return ERROR;

	/* make sure probe numbers are value */
	if(probe_number<=0 || probe_number>TT_PROBES)
		return ERROR;

	/* convert threshold values to farenheit if necessary */
	if(use_celsius==TRUE){
		warn_temp=(warn_temp*9.0/5.0)+32.0;
		crit_temp=(crit_temp*9.0/5.0)+32.0;
	        }

	return OK;
        }



/* handle timeouts */
void timeout_handler(int sig){

	printf("ERROR: Timed out waiting for data from %s\n",device);

	tcsetattr(fd,TCSANOW,&oldtios);
	close(fd);

	exit(STATE_CRITICAL);

	return;
	}

